package demo.dremio.controller;

import com.google.common.collect.ImmutableList;
import com.google.common.collect.ImmutableMap;
import org.apache.hadoop.conf.Configuration;
import org.apache.iceberg.*;
import org.apache.iceberg.aws.AwsProperties;
import org.apache.iceberg.catalog.Namespace;
import org.apache.iceberg.catalog.TableIdentifier;
import org.apache.iceberg.data.GenericRecord;
import org.apache.iceberg.data.IcebergGenerics;
import org.apache.iceberg.data.Record;
import org.apache.iceberg.data.parquet.GenericParquetWriter;
import org.apache.iceberg.io.CloseableIterable;
import org.apache.iceberg.io.DataWriter;
import org.apache.iceberg.io.OutputFile;
import org.apache.iceberg.parquet.Parquet;
import org.apache.iceberg.rest.RESTCatalog;
import org.apache.iceberg.types.Types;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

@RequestMapping("/iceberg")
@RestController
public class IcebergController {


    @GetMapping(value = "/run")
    public void run() {
        try {
            Map<String, String> properties = new HashMap<>();

            properties.put(CatalogProperties.CATALOG_IMPL, "org.apache.iceberg.rest.RESTCatalog");
            properties.put(CatalogProperties.URI, "http://iceberg-rest-ip:8181");
            properties.put(CatalogProperties.WAREHOUSE_LOCATION, "s3://warehouse/");
            properties.put(CatalogProperties.FILE_IO_IMPL, "org.apache.iceberg.aws.s3.S3FileIO");
            properties.put(AwsProperties.S3FILEIO_ENDPOINT, "http://minio-ip:9000");

            RESTCatalog catalog = new RESTCatalog();
            Configuration conf = new Configuration();
            catalog.setConf(conf);
            catalog.initialize("demo", properties);
            catalog.name();

//            SparkSession spark = SparkSession
//                    .builder()
//                    .master("local[*]")
//                    .appName("Java API Demo")
//                    .config("spark.sql.extensions", "org.apache.iceberg.spark.extensions.IcebergSparkSessionExtensions")
//                    .config("spark.sql.catalog.demo", "org.apache.iceberg.spark.SparkCatalog")
//                    .config("spark.sql.catalog.demo.catalog-impl", "org.apache.iceberg.rest.RESTCatalog")
//                    .config("spark.sql.catalog.demo.uri", "http://iceberg-rest-ip:8181")
//                    .config("spark.sql.catalog.demo.io-impl", "org.apache.iceberg.aws.s3.S3FileIO")
//                    .config("spark.sql.catalog.demo.s3.endpoint", "http://minio-ip:9000")
//                    .config("spark.sql.defaultCatalog", "demo")
//                    .config("spark.eventLog.enabled", "true")
//                    .config("spark.eventLog.dir", "/home/maria/iceberg/spark-events")
//                    .config("spark.history.fs.logDirectory", "/home/maria/iceberg/spark-events")
//                    .getOrCreate();

//            spark.sparkContext().setLogLevel("ERROR");

            Schema schema = new Schema(
                    Types.NestedField.optional(1, "Field1", Types.LongType.get()),
                    Types.NestedField.optional(2, "Field2", Types.StringType.get())
            );

            Namespace nyc = Namespace.of("nyc");
            TableIdentifier name = TableIdentifier.of(nyc, "test");

            catalog.dropTable(name);
            Table table = catalog.createTable(name, schema);

            String query = "INSERT INTO " + "demo" + ".nyc.test" + " VALUES "
                    + "(1,'aaa'), "
                    + "(2, 'error'); ";

//            spark.sql(query);

            //filter table
            Table tbl = catalog.loadTable(name);
            CloseableIterable<Record> result = IcebergGenerics.read(tbl).build();
            for (Record r: result) {
                System.out.println(r);
            }

            //add data
            GenericRecord record = GenericRecord.create(schema);
            ImmutableList.Builder<GenericRecord> builder = ImmutableList.builder();
            builder.add(record.copy(ImmutableMap.of("Field1", Long.valueOf(23), "Field2", "Bruce")));
            builder.add(record.copy(ImmutableMap.of("Field1", Long.valueOf(24), "Field2", "Wayne")));
            builder.add(record.copy(ImmutableMap.of("Field1", Long.valueOf(25), "Field2", "Clark")));
            builder.add(record.copy(ImmutableMap.of("Field1", Long.valueOf(26), "Field2", "Kent")));
            ImmutableList<GenericRecord> records = builder.build();


            String filepath = table.location() + "/" + UUID.randomUUID().toString();
            OutputFile file = table.io().newOutputFile(filepath);
            DataWriter<GenericRecord> dataWriter =
                    Parquet.writeData(file)
                            .schema(schema)
                            .createWriterFunc(GenericParquetWriter::buildWriter)
                            .overwrite()
                            .withSpec(PartitionSpec.unpartitioned())
                            .build();
            try {
                for (GenericRecord record1 : builder.build()) {
                    dataWriter.write(record1);
                }
            } catch (Exception e) {
                throw e;
            } finally {
                dataWriter.close();
            }


            DataFile dataFile = dataWriter.toDataFile();
            Table tbl1 = catalog.loadTable(name);
            tbl.newAppend().appendFile(dataFile).commit();


            CloseableIterable<Record> result1 = IcebergGenerics.read(tbl1).build();
            for (Record r: result1) {
                System.out.println(r);
            }
        } catch (Exception e) {
            System.out.println("Exception is " + e);
        }
    }
}
