package demo.dremio.controller;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.sql.*;

@RestController
@RequestMapping(value = "/dremio")
public class DriverController {

    final String DB_URL_JDBC = "jdbc:dremio:direct=localhost:31010";

    final String USER = "username";
    final String PASS = "password";

    final String JDBC_DRIVER = "com.dremio.jdbc.Driver";

    @GetMapping(value = "/run")
    public void run() throws SQLException {
        Connection conn = null;
        Statement stmt = null;
        ResultSet rs = null;
        try {
            Class.forName(JDBC_DRIVER);
            conn = DriverManager.getConnection(DB_URL_JDBC, USER, PASS);
            stmt = conn.createStatement();
            String sql;
            sql = "SELECT * FROM reportnet.reportnet.test";
            rs = stmt.executeQuery(sql);
            while (rs.next()) {
                rs.next();
            }
        } catch (Exception e) {
            System.out.println("Exception is " + e);
        } finally {
            rs.close();
            stmt.close();
            conn.close();
        }
    }
}
