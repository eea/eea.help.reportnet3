package org.example;
import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.HashMap;
import java.util.Map;

public class Main {
    public static void main(String[] args) {
        Path path = Paths.get("C:\\Users\\P63450\\Desktop\\lock_criteria");
        try {
            byte[] data = Files.readAllBytes(path);
            Map<String,Object> val = (HashMap<String, Object>) byte2Object(data);
            for (Map.Entry<String, Object>entry: val.entrySet()) {
                System.out.println("Key : " + entry.getKey() + " Value : " + entry.getValue());
            }
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }
    public static Object byte2Object(byte[] blob) {
        Object obj = new Object();

        ObjectInputStream bin;
        try {
            bin = new ObjectInputStream(new ByteArrayInputStream(blob));
            obj = bin.readObject();
        } catch (IOException e) {
            System.out.println("Unable to convert bytes to ArrayList<String> ");
        } catch (ClassNotFoundException e) {
            System.out.println("Unable to convert bytes to ArrayList<String> ");
        }
        return obj;
    }

}