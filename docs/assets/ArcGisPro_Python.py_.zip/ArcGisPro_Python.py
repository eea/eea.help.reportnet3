import arcpy
import json
import csv
import os

# === CONFIGURATION ===
input_fc = r"C:\path\to\your\input_layer.shp"       # or .gdb\FeatureClass or .geojson (if added to project)
output_csv = r"C:\path\to\output\output.csv"

# Mapping ArcGIS geometry types to GeoJSON
arcgis_to_geojson = {
    "Point": "Point",
    "Polyline": "LineString",
    "Polygon": "Polygon",
    "Multipoint": "MultiPoint"
}

# === FUNCTION TO CONVERT GEOMETRY ===
def arcgis_geom_to_geojson(shape):
    if not shape:
        return None

    geom_dict = json.loads(shape.JSON)
    geom_type = arcgis_to_geojson.get(shape.type, "GeometryCollection")

    if geom_type == "Point":
        coords = [geom_dict["x"], geom_dict["y"]]
    elif geom_type == "MultiPoint":
        coords = geom_dict["points"]
    elif geom_type == "LineString":
        coords = geom_dict["paths"][0]  # assumes single-part for simplicity
    elif geom_type == "Polygon":
        coords = geom_dict["rings"]
    else:
        coords = None

    return json.dumps({
        "type": geom_type,
        "coordinates": coords
    })

# === MAIN EXPORT ===
fields = [f.name for f in arcpy.ListFields(input_fc) if f.type not in ("Geometry", "OID")]
fields.append("geometry")

with arcpy.da.SearchCursor(input_fc, fields[:-1] + ["SHAPE@"]) as cursor, open(output_csv, "w", newline="", encoding="utf-8") as f:
    writer = csv.DictWriter(f, fieldnames=fields)
    writer.writeheader()

    for row in cursor:
        row_dict = {field: value for field, value in zip(fields[:-1], row[:-1])}
        shape = row[-1]
        row_dict["geometry"] = arcgis_geom_to_geojson(shape)
        writer.writerow(row_dict)

print(f"✅ Export completed: {output_csv}")
