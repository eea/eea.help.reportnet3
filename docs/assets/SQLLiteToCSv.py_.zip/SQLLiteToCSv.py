import sqlite3
import csv
from shapely import wkb
from shapely.geometry import mapping
import geojson
import os

# === CONFIGURATION ===
db_path = "path/to/your/spatial.db"
table_name = "your_spatial_table"
geometry_column = "geom"
output_csv = "output.csv"

# === CONNECT TO DB ===
conn = sqlite3.connect(db_path)
cursor = conn.cursor()

# === GET COLUMN NAMES (excluding geometry) ===
cursor.execute(f"PRAGMA table_info({table_name})")
columns = [col[1] for col in cursor.fetchall() if col[1] != geometry_column]

# Include geometry as final column
columns_with_geom = columns + ["geometry"]

# === SELECT DATA ===
cursor.execute(f"SELECT {', '.join(columns)}, {geometry_column} FROM {table_name}")

# === WRITE TO CSV ===
with open(output_csv, mode='w', newline='', encoding='utf-8') as f:
    writer = csv.DictWriter(f, fieldnames=columns_with_geom)
    writer.writeheader()

    for row in cursor.fetchall():
        attr_values = dict(zip(columns, row[:-1]))
        geom_wkb = row[-1]

        # Convert WKB to Shapely geometry
        geom = wkb.loads(geom_wkb, hex=True) if isinstance(geom_wkb, str) else wkb.loads(geom_wkb)
        
        # Convert to GeoJSON dict and dump as JSON string
        geojson_geom = geojson.dumps(mapping(geom))
        attr_values["geometry"] = geojson_geom

        writer.writerow(attr_values)

conn.close()
print(f"✅ CSV exported to: {output_csv}")
